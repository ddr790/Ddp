# ATLAS — Firebase + Google Login

## O que foi corrigido

- O ATLAS deixa de depender de `signInWithPopup()` para o Google Login no Android WebView.
- O Android usa Firebase Authentication + Credential Manager + Google ID Token.
- O WebView recebe apenas o resultado da autenticação; tokens não são expostos ao JavaScript.
- O estado da sessão é restaurado pelo Firebase nativo.
- O botão Back do Android fecha modal/painel e navega corretamente antes de sair do app.
- Agenda, Clima e Integrações agora são renderizados como telas reais, não como conteúdo de header sobre a tela de Configurações.

## Configuração externa obrigatória

No Firebase Console:

1. Habilite Authentication → Sign-in method → Google.
2. Cadastre o aplicativo Android com package name `com.atlas.assistant`.
3. Cadastre os certificados SHA-1 e SHA-256 usados pela assinatura do APK/AAB.
4. No Google Cloud Credentials, encontre o cliente OAuth 2.0 do tipo **Web application**.
5. Salve esse client ID no Codemagic como `ATLAS_GOOGLE_SERVER_CLIENT_ID`.

O client ID usado por `GetGoogleIdOption.setServerClientId()` deve ser o cliente Web, não o cliente Android.

No Codemagic, configure também as variáveis Firebase Web documentadas em `CODEMAGIC_SETUP.md`.

Nunca coloque service-account JSON, private keys ou client secrets no Git.


## Configuração fornecida para este build

- Firebase Android App ID: `1:69441691797:android:52e40b06ee277776b7fb9c`
- Google OAuth Web Client ID: `69441691797-g7ocrj672ls9qeojk6pndokrfejo28u0.apps.googleusercontent.com`
- Firebase API key fornecida para o build: `AIzaSyD789rGW3_B5zh5y-qR2RHP1GezB4oZPrU`

O build Android usa o **Android App ID** acima para o Firebase nativo e o **Web Client ID** acima como `serverClientId` do Credential Manager.

Ainda é necessário que o provedor Google esteja habilitado no Firebase Authentication e que o certificado que assina o APK esteja cadastrado no app Android do Firebase.
